tsc -d -p . -w &
npm run test