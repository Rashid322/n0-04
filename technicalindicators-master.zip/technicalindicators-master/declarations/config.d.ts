export declare function setConfig(key: any, value: any): void;
export declare function getConfig(key: any): any;
