import StockData from '../StockData';
import HammerPattern from './HammerPattern';
export default class HammerPatternUnconfirmed extends HammerPattern {
    constructor();
    logic(data: StockData): boolean;
}
export declare function hammerpatternunconfirmed(data: StockData): any;
