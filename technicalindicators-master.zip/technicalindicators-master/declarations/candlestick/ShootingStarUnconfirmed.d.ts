import StockData from '../StockData';
import ShootingStar from './ShootingStar';
export default class ShootingStarUnconfirmed extends ShootingStar {
    constructor();
    logic(data: StockData): boolean;
}
export declare function shootingstarunconfirmed(data: StockData): any;
