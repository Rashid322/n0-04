import StockData from '../StockData';
import CandlestickFinder from './CandlestickFinder';
export default class BullishInvertedHammerStick extends CandlestickFinder {
    constructor();
    logic(data: StockData): boolean;
}
export declare function bullishinvertedhammerstick(data: StockData): any;
