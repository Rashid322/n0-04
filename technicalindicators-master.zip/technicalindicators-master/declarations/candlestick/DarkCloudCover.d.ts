import StockData from '../StockData';
import CandlestickFinder from './CandlestickFinder';
export default class DarkCloudCover extends CandlestickFinder {
    constructor();
    logic(data: StockData): boolean;
}
export declare function darkcloudcover(data: StockData): any;
