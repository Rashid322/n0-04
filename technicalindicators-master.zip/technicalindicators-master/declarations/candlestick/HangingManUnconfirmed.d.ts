import StockData from '../StockData';
import HangingMan from './HangingMan';
export default class HangingManUnconfirmed extends HangingMan {
    constructor();
    logic(data: StockData): boolean;
}
export declare function hangingmanunconfirmed(data: StockData): any;
