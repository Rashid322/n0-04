export declare function format(v: number): number;
